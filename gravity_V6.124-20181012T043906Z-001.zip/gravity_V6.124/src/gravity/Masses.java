package gravity;

public enum Masses {

}
