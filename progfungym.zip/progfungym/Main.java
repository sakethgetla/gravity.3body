
/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Main
{

    public static void main(String [] args){
        Game game = new Game();
            game.print() ;
        while(game.gameFinished() != true ){
            game.gameFinished();
            game.moveEnemies();

            if(game.gameRunning){
                game.movePlayer();
            }
            game.print() ;

        }
        System.out.print("You won!");
    }
}
