import java.util.Scanner;
public class Global
{
    // Rather than create a new Scanner in each of your classes,
    // use the global Scanner "keyboard" declared below
    public static final Scanner keyboard = new Scanner(System.in);
    /**
     * @return
    an integer inputted by the user
     */
    public static int promptInt(String prompt)
    {
        System.out.print(prompt);
        int value = keyboard.nextInt();
        keyboard.nextLine();
        return value;
    }

    /**
     * @return
    a move inputted by the user
     */
    public static char readMove()
    {
        System.out.print("move: ");
        char move = keyboard.nextLine().charAt(0);
        return move;
    }
}