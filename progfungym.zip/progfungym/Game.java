
/**
 * Write a description of class Game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game
{
    // instance variables - replace the example below with your own
    private int x;
    PlayerShip player;
    private static EnemyShip enemy1, enemy2, enemy3 ;
    public boolean gameRunning = true;

    /**
     * Constructor for objects of class Game
     */
    public Game()
    {
        // initialise instance variables
        //System.out.print(-13%12);
        player = new PlayerShip();
        enemy1 = new EnemyShip();
        enemy2 = new EnemyShip();
        enemy3 = new EnemyShip();

       

    }
    public String toString(){
        String s = enemy1.toString() +" "+enemy2.toString() +" "+enemy3.toString()  +" "+player.toString() ;
        return s; 
    }

 
    public void movePlayer(){
    // moveEnemies();
        switch(Global.readMove())
        {
            case 'r':
            case 'R':
            updateLastHit();
            player.move(1);
           justFired(false);
           
            break;
            
            case 'L':
            case 'l':
            updateLastHit();
            player.move(-1);
            justFired(false);
        
            break;
            
            case 'f':
            case 'F':
            //updateLastHit();
            fire(player, enemy1);
            fire(player, enemy2);
            fire(player, enemy3);
            justFired(true);
            break;

        }        

    }

    public void justFired(boolean b){
      player.setJustFiredg1(b);
        player.setJustFiredg2(b);        
        //        public static void main(String [] args)
    }

    public void updateLastHit(){
        player.setLastHitg1(player.getLastHitg1()+1);
        player.setLastHitg2(player.getLastHitg2()+1);    
      
    }

   

    public void fire(PlayerShip p1, EnemyShip e1){
        e1.justHit =false;
        if (p1.getPosg1()==e1.getPos() && e1.getLife() >=0 ){
            e1.setLife(p1.getPowerg1());
            e1.justHit =true;
            if (e1.getLife() <1){
             
                if (p1.getLastHitg1() <=7){
                    p1.setPtsg1(1+ (7-p1.getLastHitg1()));
                }else{
                    p1.setPtsg1(+1);
                }

                p1.setLastHitg1(0);
            }
        }else  if (p1.getPosg2()==e1.getPos() &&  e1.getLife() >=0){
            e1.setLife(p1.getPowerg2());
            e1.justHit =true;
            if (e1.getLife() <1){
       
                if (p1.getLastHitg2() <=7){
                    p1.setPtsg2(1+ (7-p1.getLastHitg2()));
                }else{
                    p1.setPtsg2(1);
                }

                p1.setLastHitg2(0);
            }
        }else{
           updateLastHit();
        }

        // gameFinished();
    }

    public static boolean gameFinished(){
        if (enemy1.getLife() <= 0 && enemy2.getLife() <= 0  && enemy3.getLife() <= 0 ){  
            return true;
        }
        return false;
    }

    public void print(){
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println(enemy1.print());
        System.out.println(enemy2.print());
        System.out.println(enemy3.print());
        System.out.println();
        System.out.println();
        String s;
       
            
        
        System.out.println(player.print());
        System.out.print(player.getPtsg1()+player.getPtsg2() +" pts. ");
        //Global.readMove();
        // movePlayer();
    }

    public void moveEnemies(){
        enemy1.move();
        enemy3.move();
        enemy2.move();
    }
}
