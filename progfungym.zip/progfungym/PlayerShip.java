
/**
 * Write a description of class PlayerShip here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PlayerShip
{
    // instance variables - replace the example below with your own

    private int position ;
    private Gun gun1 ,gun2;
    /**
     * Constructor for objects of class PlayerShip
     */
    public PlayerShip()
    {
        position = Global.promptInt("Player position: ");
        gun1 = new Gun(position-1,5);
        gun2 = new Gun(position+1,5);
        

    }

    public void move(int move)
    {
        if (position+move <= 5 && position+move >= -5){

            this.position += move;
            gun1.move(move);
            gun2.move(move);
        }

    }

    public boolean getJustFiredg1(){
        return gun1.getJustFired();
    }

    public void setJustFiredg1(boolean P){
        gun1.setJustFired(P);
    }
    
        public boolean getJustFiredg2(){
        return gun2.getJustFired();
    }

    public void setJustFiredg2(boolean P){
        gun2.setJustFired(P);
    }


    public int getLastHitg1(){
        return gun1.getLastHit();
    }

    public void setLastHitg1(int P){
        gun1.setLastHit(P);
    }

    public int getLastHitg2(){
        return gun2.getLastHit();
    }

    public void setLastHitg2(int P){
        gun2.setLastHit(P);
    }

    public int getPosg1(){
        return gun1.getPos();
    }

    public int getPowerg1(){
        return gun1.getPower();
    }

    public void setPtsg1(int pts){
        gun1.setPts(pts);
    }

    public int getPtsg1(){
        return gun1.getPts();
    }

    public int getPosg2(){
        return gun2.getPos();
    }

    public int getPowerg2(){
        return gun2.getPower();
    }

    public void setPtsg2(int pts){
        gun2.setPts(pts);
    }

    public int getPtsg2(){
        return gun2.getPts();
    }

    public String toString(){
        int totalPts = gun1.getPts()+gun2.getPts();
        return "Player["+position+", "+totalPts+"pts]";
    }

    
    public String gunSym(Gun g){
        String ss;
         if (g.getJustFired()){
                ss = "x";
            }else{
                ss = "i";                
            }
        return ss;
    }
    
    
    public String print(){
        String s = null ;

        // if (-6==position){
            // s = "A";
        // }else if (-6==gun1.getPos() ){
            // if (gun1.getJustFired()){
                // s = "x";
            // }else{
                // s = "i";                
            // }
        // }else if (-6==gun2.getPos()){
            // if (gun2.getJustFired()){
                // s = "x";
            // }else{
                // s = "i";                
            // }
        // }else{
            // s = "_";
        // }

        for (int i =-6 ;i<=6;i++){
            if (i==position){
                s += "A";
            }else if (i==gun1.getPos() ){
                if (gun1.getJustFired()){
                    s += "x";
                }else{
                    s += "i";                
                }
            }else if (i==gun2.getPos()){
                if (gun2.getJustFired()){
                    s += "x";
                }else{
                    s += "i";                
                }
            }else{
                s += "_";
            }
        }

        return s;
    }

}
