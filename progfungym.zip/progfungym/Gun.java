
/**
 * Write a description of class Gun here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Gun {
    // instance variables - replace the example below with your own
    private int position =0,power=0,points, lastHit=7 ; 
    private boolean justFired = false;

    /**
     * Constructor for objects of class Gun
     */

    public Gun(int position,int power)
    {
        // initialise instance variables
        this.position = position;
        this.power = power;
    }

    public void move(int move){
        position += move;
    }

    public int getPts(){
        return points;
    }

    public void setPts(int P){
        points += P;
    }

    public int getLastHit(){
        return lastHit;
    }

    public void setLastHit(int P){
        lastHit = P;

    }

    public int getPos(){
        return position;
    }

    public int getPower(){
        return power;
    }

    public void setJustFired(boolean P){
        justFired = P;
    }

    public boolean getJustFired(){
        return justFired;
    }
}
