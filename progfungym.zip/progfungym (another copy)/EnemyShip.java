
/**
 * Write a description of class EnemyShip here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EnemyShip
{
    // instance variables - replace the example below with your own
    private int position,velocity,life;

    private boolean justHit ;
    private static int number=0;

    /**
     * Constructor for objects of class EnemyShip
     */
    public void setJustHit(boolean P){
        justHit= P;
    }

    public boolean getJustHit(){
        return justHit;
    }

    public EnemyShip()
    {
        number++;
        System.out.println("Enemy #"+number);
        // initialise instance variables
        position = Global.promptInt("- Initial position: ");
        velocity= Global.promptInt("- Initial velocity: ");
        life = 10;
        justHit =false;
    }

    public String toString(){
        return "Enemy("+position+")";
    }

    public int getPos(){
        return position;
    }

    public int getLife(){
        return life;
    }

    public void setLife(int LIFE){
        this.life = LIFE; 
    }

    public void move(){
        if (life >0){
            if (position +velocity >6 ){ 

                // position = 6- (position +velocity -6) ;
                // velocity *= -1;
                int a = ((position +velocity-6)/12);

                if( a% 2 == 0){ 

                    position = 6 - ((position +velocity-6)%12);
                    velocity *= -1;
                }else{

                    position = -6 + ((position +velocity+6)%12);
                    velocity *= 1;
                }

            }else if (position +velocity < -6 ){ 

                // position = -6 -(position +velocity +6) ;
                // velocity *= -1;
                int a = (position +velocity+6)/12;
                if(a% 2 == 0){ 

                    position = -6 - ((position +velocity+6)%12);
                    velocity *= -1;
                    // position =-15;            
                }else{ 
                    velocity *= 1;
                    position = -6 - ((position +velocity+6)%12);
                }

            }else{
                position += velocity;
            }
        }   
    }
    

    public String print(){
        String s ;
        if (-6==position){
            if (life <1){
                s = "X";
            }else if( justHit){
                s = "x";

            } else{
                s = "e";
            }
        }
        else{
            s = ".";
        }
        for (int i =-5 ;i<=6;i++){
            if (i==position){
                if(life <1 ){
                    s += "X";

                }else if ( justHit){
                    s += "x";
                }else{
                    s += "e";
                }
            }else{
                s += ".";
            }

        }
        return s;
    }
}
