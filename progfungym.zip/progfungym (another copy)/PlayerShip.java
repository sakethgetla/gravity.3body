
/**
 * Write a description of class PlayerShip here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PlayerShip
{
    // instance variables - replace the example below with your own

    private int position ;
    public Gun gun1 ,gun2;
    /**
     * Constructor for objects of class PlayerShip
     */
    public PlayerShip()
    {
        position = Global.promptInt("Player position: ");
        gun1 = new Gun(position-1,5);
        gun2 = new Gun(position+1,5);

    }

    public void move(int move)
    {
        if (position+move <= 5 && position+move >= -5){

            position += move;
            gun1.move(move);
            gun2.move(move);
        }

    }

    public String toString(){
        int totalPts = gun1.getPts()+gun2.getPts();
        return "Player["+position+", "+totalPts+"pts]";
    }

    public String letter(Gun gun){
        String s;
        if (gun.getJustFired()){
            s = "x";
        }else{
            s = "i";                
        }
        return s;
    }

    public String print(){
        String s = null ;

        if (-6==position){
            s = "A";
        }else if (-6==gun1.getPos() ){

            s = letter(gun1);
        }else if (-6==gun2.getPos()){
            s = letter(gun2);
        }else{
            s = "_";
        }

        for (int i =-5 ;i<=6;i++){
            if (i==position){
                s += "A";
            }else if (i==gun1.getPos() ){
                s += letter(gun1);
            }else if (i==gun2.getPos()){
                s += letter(gun2);
            }else{
                s += "_";
            }
            //}

        }
        // public String gunP(Gun gun){
        return s;
        // }
    }
}
