
/**
 * Write a description of class Game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game
{
    // instance variables - replace the example below with your own
    // private int x;
    PlayerShip player;
    private  EnemyShip enemy1, enemy2, enemy3 ;
    //public boolean gameRunning = true;

    /**
     * Constructor for objects of class Game
     */
    public Game()
    {
        // initialise instance variables
        //System.out.print(-13%12);
        player = new PlayerShip();
        enemy1 = new EnemyShip();
        enemy2 = new EnemyShip();
        enemy3 = new EnemyShip();

        player.gun1.getPos();

    }

    public String toString(){
        String s = enemy1.toString() +" "+enemy2.toString() +" "+enemy3.toString()  +" "+player.toString() ;
        return s; 
    }

    public void movePlayer(){
        switch(Global.readMove())
        {
            case 'r':
            case 'R':
            updateLastHit();
            player.move(1);
            justFired(false);
            break;

            case 'L':
            case 'l':
            updateLastHit();
            player.move(-1);
            justFired(false);
            break;

            case 'f':
            case 'F':
            updateLastHit();
            fire(player.gun1, enemy1);
            fire(player.gun1, enemy2);
            fire(player.gun1, enemy3);

            fire(player.gun2, enemy1);
            fire(player.gun2, enemy2);
            fire(player.gun2, enemy3);
            justFired(true);
            break;

        }        

    }

    public void justFired(boolean b){
        player.gun1.setJustFired(b);
        player.gun2.setJustFired(b);        
        //        public static void main(String [] args)
    }

    public void updateLastHit(){
        player.gun1.setLastHit(player.gun1.getLastHit()+1);
        player.gun2.setLastHit(player.gun2.getLastHit()+1);   
        enemy1.setJustHit(false);
        enemy2.setJustHit(false);
        enemy3.setJustHit(false);

    }

    public void justHit(boolean b){

    }

    public void fire(Gun gun, EnemyShip e){
        if (gun.getPos()==e.getPos() &&  e.getLife() > 0 ){
            e.setLife(e.getLife()- gun.getPower());
            e.setJustHit(true);
            if (e.getLife() <1){

                if (gun.getLastHit() <=7){
                    gun.addPts(1+ (7- gun.getLastHit()));
                }else{
                    gun.addPts(+1);
                }

                gun.setLastHit(0);
            }
        }

        // gameFinished();
    }

    public boolean gameFinished(){
        if (enemy1.getLife() <= 0 && enemy2.getLife() <= 0  && enemy3.getLife() <= 0 ){  
            return true;
        }
        return false;
    }

    public void print(){

      
           ;
        
        System.out.println("\n"+"\n"+"\n"+enemy1.print()
            +"\n"+enemy2.print()+"\n"+enemy3.print()+"\n"+"\n");
        System.out.println(player.print());
        System.out.print(player.gun1.getPts()+player.gun2.getPts() +" pts. ");
        //Global.readMove();
        // movePlayer();
    }

        
    public void moveEnemies(){
        enemy1.move();
        enemy3.move();
        enemy2.move();
    }
}
