package controller;

import au.edu.uts.ap.javafx.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import model.*;

public class BuildController extends Controller<Build>{
    
    public final Build getModel() {
        return model;
    }

    public final Stage getStage() {
        return stage;
    }
    @FXML private void checkBuild(ActionEvent event) throws Exception{

    }

    @FXML private void removeSelected(ActionEvent event) throws Exception{

    }
    @FXML private void close(ActionEvent event) throws Exception{
	getStage().close();
    }


    

}
