package controller;

import javafx.stage.Stage;
import au.edu.uts.ap.javafx.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import model.*;

public class CatalogueController  extends Controller<Catalogue>{

    public final Catalogue getModel() {
        return model;
    }

    public final Stage getStage() {
        return stage;
    }
    @FXML private void add2Build(ActionEvent event) throws Exception{

    }
    @FXML private void add2Cat(ActionEvent event) throws Exception{
    
    }
    @FXML private void removeFromCat(ActionEvent event) throws Exception{

    }
    @FXML private void close(ActionEvent event) throws Exception{
	getStage().close();
    }


}
