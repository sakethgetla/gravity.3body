package controller;

import au.edu.uts.ap.javafx.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import model.*;

public class ComputerBuilderController extends Controller<ComputerBuilder>{

    public final ComputerBuilder getModel() {
        return model;
    }

    public final Stage getStage() {
        return stage;
    }

    @FXML private void viewCatalogue(ActionEvent event) throws Exception{
	System.out.println("view Cat");
	ViewLoader.showStage(getModel().getCatalogue() , "/view/catalogue.fxml", "Catalogue", new Stage());

    }
    
    @FXML private void viewBuild(ActionEvent event) throws Exception{
	System.out.println("view build");
//ViewLoader.showStage(new ComputerBuilder(), "/view/computerbuilder.fxml", "Guillermo's Computer Store", stage);

	ViewLoader.showStage(getModel().getBuild(), "/view/build.fxml", "Current Build", new Stage());
    }
    @FXML private void quit(ActionEvent event) throws Exception{
	getStage().close();
    }

}
